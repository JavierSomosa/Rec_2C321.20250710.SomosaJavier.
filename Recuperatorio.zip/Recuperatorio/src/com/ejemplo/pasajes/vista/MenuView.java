/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.pasajes.vista;
import com.ejemplo.pasajes.modelo.Vendedor;
import java.util.HashMap;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.ejemplo.pasajes.modelo.Vendedor;
import javafx.scene.Scene;
import javafx.scene.control.Button;

/**
 *
 * @author Javier
 */
public class MenuView {
    private Stage stage;
    private Vendedor vendedor;
    private HashMap <String, Vendedor> vendedores;

    public MenuView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        this.stage = stage;
        this.vendedor = vendedor;
        this.vendedores = vendedores;
    }
    
    public void mostrar(){
        VBox layout = new VBox(10);
        Button ventaBtn = new Button("realizar venta");
        Button consultaBtn = new Button("consultar ventas");
        Button salirBtn = new Button("cerrar sesion");
        
        ventaBtn.setOnAction(e -> new VentaView(stage, vendedor, vendedores).mostrar());
        consultaBtn.setOnAction(e -> new ConsultaView(stage, vendedor, vendedores).mostrar());
        salirBtn.setOnAction(e -> new LoginView(stage, vendedores).mostrar());
        
        layout.getChildren().addAll(ventaBtn, consultaBtn, salirBtn);
        stage.setScene(new Scene(layout, 300, 200));
        stage.setTitle("Menu");
        stage.show();
                
    }
}
