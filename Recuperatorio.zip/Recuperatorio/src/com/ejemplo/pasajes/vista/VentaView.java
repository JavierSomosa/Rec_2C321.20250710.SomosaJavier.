/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.pasajes.vista;

import com.ejemplo.pasajes.modelo.Vendedor;
import com.ejemplo.pasajes.persistencia.PersistenciaVendedores;
import java.util.HashMap;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Javier
 */
public class VentaView {
    private Stage stage;
    private Vendedor vendedor;
    private HashMap <String, Vendedor> vendedores;

    public VentaView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        this.stage = stage;
        this.vendedor = vendedor;
        this.vendedores = vendedores;
    }
    
    public void mostrar(){
        VBox layout= new VBox(10);
        
        TextField origenField = new TextField();
        TextField destinoField = new TextField();
        TextField cantidadField = new TextField();
        Label totalLabel = new Label();
        Button venderBtn = new Button("Confirmar venta");
        Button volverBtn = new Button("volver");
        
        venderBtn.setOnAction(e -> {
            int cantidad = Integer.parseInt(cantidadField.getText());
            int total = cantidad * 250;
            vendedor.agregarPasajes(cantidad);
            PersistenciaVendedores.guardar(vendedores);
            totalLabel.setText("Venta realizada");
        });
        
        volverBtn.setOnAction(e -> new MenuView(stage, vendedor, vendedores).mostrar());
        
        layout.getChildren().addAll(
                new Label("Origen"), origenField,
                new Label("Destino"), destinoField,
                new Label("cantidad de pasajes"), cantidadField,
                venderBtn, totalLabel, volverBtn
        );
        
        stage.setScene(new Scene(layout, 300, 300));
        stage.setTitle("Venta de Pasajes");
        stage.show( );
    }
}
