/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.pasajes.vista;

import com.ejemplo.pasajes.modelo.Vendedor;
import com.ejemplo.pasajes.persistencia.PersistenciaVendedores;
import java.util.HashMap;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Javier
 */
public class LoginView {
    private HashMap <String, Vendedor> vendedores;
    private Stage stage;

    public LoginView(Stage stage, HashMap <String, Vendedor> vendedores) {
        this.stage = stage;
        this.vendedores = vendedores;
    }
    
    public void mostrar(){
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        
        TextField usuarioField = new TextField();
        PasswordField pinField = new PasswordField();
        Button loginBtn = new Button("Ingresar");
        Button registrarBtn = new Button("Registrarse");
        Label mensaje = new Label();
        
        root.getChildren().addAll(new Label("Usuario"), usuarioField, new Label("Pin:"), pinField, loginBtn);
        
        loginBtn.setOnAction(e -> {
           String user = usuarioField.getText();
           String pin = pinField.getText();          
           
           Vendedor vendedor = vendedores.get(user);
           if (vendedor != null && vendedor.getPin().equals(pin)){
               new MenuView(stage, vendedor, vendedores).mostrar();
           }else{
               Alert alert = new Alert(AlertType.ERROR, "Usuario o PIN incorrectos");
               alert.showAndWait();
           }
        });
        
        stage.setScene(new Scene(root, 300, 200));
        stage.setTitle("Login");
        stage.show();
    }
}
