/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.pasajes.vista;

import com.ejemplo.pasajes.modelo.Vendedor;
import java.util.HashMap;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Javier
 */
public class ConsultaView {
    private Stage stage;
    private Vendedor vendedor;
    private HashMap <String, Vendedor> vendedores;

    public ConsultaView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        this.stage = stage;
        this.vendedor = vendedor;
        this.vendedores = vendedores;
    }
    
    public void mostrar(){
        VBox layout = new VBox(10);
        Label info = new Label("Pasajes vendido: " + vendedor.getPasajeVendidos());
        Button volverBtn = new Button("Volver");
        
        volverBtn.setOnAction(e -> new MenuView(stage, vendedor, vendedores).mostrar());
        
        layout.getChildren().addAll(info, volverBtn);
        stage.setScene(new Scene(layout, 250, 150));
        stage.setTitle("Consulta de ventas");
        stage.show();
    }
}
