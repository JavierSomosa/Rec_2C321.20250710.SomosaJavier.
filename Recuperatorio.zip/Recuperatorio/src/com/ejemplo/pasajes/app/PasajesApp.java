/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.ejemplo.pasajes.app;

import com.ejemplo.pasajes.modelo.Vendedor;
import com.ejemplo.pasajes.persistencia.PersistenciaVendedores;
import com.ejemplo.pasajes.vista.LoginView;
import java.io.IOException;
import java.util.HashMap;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author Javier
 */
public class PasajesApp extends Application{

    private HashMap <String, Vendedor> vendedores;
    
    @Override
    public void start (Stage primaryStage) throws IOException, ClassNotFoundException{
        vendedores = PersistenciaVendedores.cargar();
        
        //puse para ver 1
        if(!vendedores.containsKey("admin")) {
            vendedores.put("admin", new Vendedor("admin", "1234", 0));
        }
        
        new LoginView(primaryStage, vendedores).mostrar();
    }
    
    @Override
    public void stop(){
        PersistenciaVendedores.guardar(vendedores);
    }
                       
    public static void main(String[] args) {
        launch(args);
    }
    
}
