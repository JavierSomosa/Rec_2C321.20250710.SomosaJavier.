/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.pasajes.persistencia;

import com.ejemplo.pasajes.modelo.Vendedor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
/**
 *
 * @author Javier
 */
public class PersistenciaVendedores {
    private static final String ARCHIVO = "vendedores.ser ";
    public static void guardar(HashMap<String, Vendedor> vendedores) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            out.writeObject(vendedores);
        } catch(IOException e){
            e.printStackTrace(); 
        }
    }

    public static HashMap<String, Vendedor > cargar() throws FileNotFoundException, IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ARCHIVO))){
            return (HashMap<String, Vendedor>) in .readObject();
        } catch(IOException | ClassNotFoundException e) {
            return new HashMap<>();
        }
    }
    
}
